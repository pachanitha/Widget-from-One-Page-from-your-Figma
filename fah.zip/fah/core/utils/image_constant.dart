class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // News XD images
  static String imgMobile = '$imagePath/img_mobile.svg';

  static String imgImage6 = '$imagePath/img_image_6.png';

  static String imgRightArrow3 = '$imagePath/img_right_arrow_3.png';

  // Create images
  static String imgRightArrow4 = '$imagePath/img_right_arrow_4.png';

  // Profile images
  static String imgAionyHaust3tl = '$imagePath/img_aiony_haust_3tl.png';

  static String imgGroup17 = '$imagePath/img_group_17.png';

  static String imgEditing1 = '$imagePath/img_editing_1.png';

  static String imgImage6255x184 = '$imagePath/img_image_6_255x184.png';

  static String imgImage12 = '$imagePath/img_image_12.png';

  // Common images
  static String imgBookmark3 = '$imagePath/img_bookmark_3.png';

  static String imgImage9 = '$imagePath/img_image_9.png';

  static String imgImage10 = '$imagePath/img_image_10.png';

  static String imgHome12 = '$imagePath/img_home_1_2.png';

  static String imgCopyWriting2 = '$imagePath/img_copy_writing_2.png';

  static String imgUser2 = '$imagePath/img_user_2.png';

  static String imgImage11 = '$imagePath/img_image_11.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
