import 'package:flutter/material.dart';
import 'package:ntnc_s_application5/core/app_export.dart';

// ignore_for_file: must_be_immutable
class StoryPage extends StatelessWidget {
  const StoryPage({Key? key})
      : super(
          key: key,
        );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: appTheme.gray900,
        body: Container(
          width: double.maxFinite,
          padding: EdgeInsets.symmetric(horizontal: 22.h),
          decoration: AppDecoration.fillGray900,
          child: Row(
            children: [
              Expanded(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: SizeUtils.height,
                      child: VerticalDivider(
                        width: 1.h,
                        thickness: 1.v,
                        color: appTheme.blueGray100E5,
                      ),
                    ),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.only(
                          left: 7.h,
                          top: 82.v,
                          bottom: 160.v,
                        ),
                        child: Column(
                          children: [
                            Container(
                              width: 307.h,
                              margin: EdgeInsets.only(
                                left: 24.h,
                                right: 25.h,
                              ),
                              child: Text(
                                "The Alumni Affairs and Career Development Group of the Office of Student Affairs, Mahidol University International College (MUIC) organized an “Unlocking Opportunities: Job Fair Readiness for Non-Business Majors” on January 17, 2024 at Charinyarasami Hall, Aditayathorn Building.",
                                maxLines: 7,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.justify,
                                style: theme.textTheme.bodyMedium!.copyWith(
                                  height: 1.79,
                                ),
                              ),
                            ),
                            SizedBox(height: 3.v),
                            _buildEventImages(context),
                            SizedBox(height: 23.v),
                            Container(
                              width: 307.h,
                              margin: EdgeInsets.only(
                                left: 21.h,
                                right: 28.h,
                              ),
                              child: Text(
                                "This event, attended by 55 students, offered ideas and opportunities for non-business major students to prepare for job application in the upcoming MUIC Job Fair on January 24-25. Mr. Richard Jones, Senior Vice President, Indorama Ventures Public Co. Ltd., and Director of IVL Foundation, was a guest speaker. He discussed the following topics:\nReaching Out to Potential Employers\nExploring Beyond Your Major: Can You Apply for Diverse Positions?\nPresenting Yourself for the Desired Position",
                                maxLines: 12,
                                overflow: TextOverflow.ellipsis,
                                textAlign: TextAlign.justify,
                                style: theme.textTheme.bodyMedium!.copyWith(
                                  height: 1.79,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Section Widget
  Widget _buildEventImages(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        CustomImageView(
          imagePath: ImageConstant.imgImage9,
          height: 110.v,
          width: 175.h,
          margin: EdgeInsets.only(bottom: 1.v),
        ),
        CustomImageView(
          imagePath: ImageConstant.imgImage10,
          height: 111.v,
          width: 171.h,
        ),
      ],
    );
  }
}
